package com.movie.movie.controller;

public class MovieController {
}
