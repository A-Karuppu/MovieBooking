package com.movie.movie.restconnector;

public class AuthClient {
}
